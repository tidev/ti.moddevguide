// Ensure that the module development guide module is loaded		
var DevGuide = require('ti.moddevguide');

// Open the main category selection page
require('navigator').start(DevGuide);